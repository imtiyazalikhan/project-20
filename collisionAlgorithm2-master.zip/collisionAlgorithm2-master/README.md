# collisionAlgorithm2
collision algorithm to detect collision between any two game objects
